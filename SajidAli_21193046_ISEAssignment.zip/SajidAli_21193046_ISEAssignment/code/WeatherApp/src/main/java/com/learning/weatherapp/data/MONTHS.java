package com.learning.weatherapp.data;

public enum MONTHS {
        January, February, March, April, May, June, July, August, September, October, November, December
    }
