## ali_sajid21193046_ISErepo

An educational software projects aims at developing software tools supporting learning about weather and impact of weather changes.

**Purpose of each file**
- `.git` is used for version controlling
- `SajidAli_21190346_Report.md` Software documentation
- `SajidAli_21190346_ISEReport.pdf` This pdf is created for submission2 (documention submission)
- `DeclarationOfOriginality_v1.2.pdf` Originality declation cover-sheet
- `code` this folder contains all the `production` and `test code` with `testcases`